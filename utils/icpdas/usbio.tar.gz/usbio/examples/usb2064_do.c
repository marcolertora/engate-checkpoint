/*
 *  usb2064_do.c
 *
 *  v 0.0.0 2013.4.9 by Golden Wang
 *
 *  open USB-2064, then enable DO
 *
 */

#include "ICPDAS_USBIO.h"

int main()
{
	int fd;						/* file descriptor */
	int res;
	BYTE total_do = 0, do_conf = 0, do_value = 0;
	int DevNum;
	BYTE BoardID = 0x01;

	printf("USB I/O Library Version : %s\n", USBIO_GetLibraryVersion());

	res = USBIO_OpenDevice(BoardID, &DevNum);

        if (res)
        {
                printf("open /dev/hidraw%d failed! Erro : %d\r\n",  DevNum, res);
                return 0;
        }
	
/*
	res = USBIO_RefreshDeviceInfo(DevNum);

	if (res)
	{
		res = USBIO_CloseDevice(DevNum);

	        if(res)
        	{
                	printf("close /dev/hidraw%d failed! Erro : %d\r\n",  DevNum, res);
	                return 0;
        	}
	}
*/

	//USBIO_LoadDefault(DevNum);	

/*
	BYTE b;
	BYTE a[8],c[8];
	int i =0;
	memset(a,0,1);
	USBIO_DO_SetSafetyEnable(DevNum, &a);
	USBIO_DO_GetSafetyEnable(DevNum, &b);  //default is 0
	printf("USBIO_DO_GetSafetyEnable is %d\n",b);
	
	memset(a, 1, 4);
	printf("a is %d\n",a[0]);
	USBIO_DO_SetPowerOnEnable(DevNum, a);
	USBIO_DO_GetPowerOnEnable(DevNum, c);
	for(i =0;i < 5;i++)
		printf("c is %d\n",c[i]);
*/

	USBIO_SetUserDefinedBoardID(DevNum, 126);

	USBIO_GetDOTotal(DevNum, &total_do);
	printf("USB-2064 DO Number : %d\n",total_do);

	do_value = 0xff;	//Enable all USB-2064 DO channel
	USBIO_DO_WriteValue(DevNum, &do_value);
	printf("USB-2064 DO Value : 0x%x\n",do_value);

	USBIO_DO_ReadValue(DevNum, &do_conf);
	printf("USB-2064 DO Config : 0x%x\n",do_conf);

	sleep(3);

	do_value = 0;        //Disable all USB-2064 DO channel
        USBIO_DO_WriteValue(DevNum, &do_value);
        printf("USB-2064 DO Value : 0x%x\n",do_value);

        USBIO_DO_ReadValue(DevNum, &do_conf);
        printf("USB-2064 DO Config : 0x%x\n",do_conf);

	res = USBIO_CloseDevice(DevNum);

	if(res)
	{
                printf("close /dev/hidraw%d failed! Erro : %d\r\n",  DevNum, res);
                return 0;
        }

	return (0);
}
