/*
 *  usb2019_ai.c
 *
 *  v 0.0.0 2014.4.14 by Winson Chen
 *
 *    create
 *
 */

#include "ICPDAS_USBIO.h"

int main()
{
	int fd;						/* file descriptor */
	int res,i;
	BYTE total_ai;
	int DevNum;
	BYTE BoardID = 0x1;

	printf("USB I/O Library Version : %s\n", USBIO_GetLibraryVersion());

	res = USBIO_OpenDevice(BoardID, &DevNum);

        if (res)
        {
                printf("open /dev/hidraw%d failed! Erro : %d\r\n",  DevNum, res);
                return 0;
        }

	USBIO_GetAITotal(DevNum, &total_ai);
	printf("USB-2019 AI Number : %d\n",total_ai);
/*
	USBIO_LoadDefault(DevNum);
*/
/*  not done
	BYTE SN[32];
	USBIO_GetDeviceSN(DevNum, SN);
	printf("SN is %s\n",SN);
*/
/*
	DWORD timeout;
	USBIO_SetCommTimeout(DevNum, 100);
	USBIO_GetCommTimeout(DevNum, &timeout);  //default is 100000
	printf("timeout is %d\n",timeout);
*/
/*
	DWORD time;
	//USBIO_SetSoftWDTTimeout(DevNum, 10000);
	USBIO_GetSoftWDTTimeout(DevNum, &time);  //default is 0
	printf("timeout is %d\n",time);
*/
/*
	DWORD ID;
	USBIO_SetUserDefinedBoardID(DevNum, 123);
	USBIO_GetDeviceID(DevNum, &ID);
	printf("0x%x\n",ID);
*/
/*
	BYTE gnick[50],snick[50] = "USB-2019";
	USBIO_SetDeviceNickName(DevNum, snick);
	USBIO_GetDeviceNickName(DevNum, gnick);
	printf("%s\n",gnick);
*/
/*
	BYTE totalsupporttype;

	USBIO_AI_GetTotalSupportType(DevNum, &totalsupporttype);  //Get type code amount
	printf("GetTotalSupportType is %d\n",totalsupporttype);
*/
/*
	BYTE o_bySupportTypeCode[50];

	USBIO_AI_GetSupportTypeCode(DevNum, o_bySupportTypeCode);  //list all type code 
	for(i = 0; i < 27; i++)
		printf("o_bySupportTypeCode is %02x\n",o_bySupportTypeCode[i]);
*/
/*
	BYTE stc[16], gtc[16];
	
	for(i = 0; i < 16; i++)
		stc[i] = 0x8;
	USBIO_AI_SetTypeCode(DevNum, stc);
	USBIO_AI_SetTypeCodeToChannel(DevNum, 1, 0x8);
	USBIO_AI_GetTypeCode(DevNum, gtc);
	for(i = 0; i < 8; i++)
		printf("gettypecode is %02x\n",gtc[i]);
*/
/*
	float gchCJCoffset[16], schCJCoffset[16];
	for(i = 0; i < 16; i++)
	{
		schCJCoffset[i] = 1.99521;
	}
	USBIO_AI_SetChCJCOffset(DevNum, schCJCoffset);
	USBIO_AI_SetChCJCOffsetToChannel(DevNum, 1, 1.777);
	USBIO_AI_GetChCJCOffset(DevNum, gchCJCoffset);
	for(i = 0; i < 8; i++)
		printf("chCJCoffset%d is %.5f\n",i,gchCJCoffset[i]);
*/
/*
	BYTE CJCenable;
	USBIO_AI_SetCJCEnable(DevNum, 1);
	USBIO_AI_GetCJCEnable(DevNum, &CJCenable);  //default is 1
	printf("CJCenable is %d\n",CJCenable);
*/

	BYTE gChEnable[2], sChEnable[2];
        for(i = 0; i < 2; i++)
		sChEnable[i] = 0xff;
	USBIO_AI_SetChEnable(DevNum, sChEnable);
	USBIO_AI_GetChEnable(DevNum, gChEnable);
	for(i = 0; i < 2; i++)
		printf("gChEnable is %x\n",gChEnable[i]);

/*
	float gCJCoffset;
	USBIO_AI_SetCJCOffset(DevNum, 10.33);
	USBIO_AI_GetCJCOffset(DevNum, &gCJCoffset);  //default is 0
	printf("%.5f\n",gCJCoffset);
*/
/*
	BYTE Resolution[8];
	USBIO_AI_GetResolution(DevNum, Resolution);
	for(i = 0; i < 8; i++)
		printf("Resolution is %d\n",Resolution[i]);
*/
/*
	BYTE gWireDetectEnable;
	USBIO_AI_SetWireDetectEnable(DevNum, 1);
	USBIO_AI_GetWireDetectEnable(DevNum, &gWireDetectEnable);  //default is 1
	printf("AI_GetWireDetectEnable is %d\n",gWireDetectEnable);
*/
/*
	BYTE gFilterRejection;
	USBIO_AI_SetFilterRejection(DevNum, 0);
	USBIO_AI_GetFilterRejection(DevNum, &gFilterRejection);
	printf("FilterRejection is %d\n",gFilterRejection);  //default is 0  60Hz
*/
/*
	BYTE format;
	USBIO_AI_SetDataFormat(DevNum,0);
	USBIO_AI_GetDataFormat(DevNum, &format);  //default is 0
	printf("Data format is %d\n",format);
*/
/*
	float cjc;
	while(1)
	{
		USBIO_AI_ReadCJCValue(DevNum,  &cjc);
		printf("CJCvalue is %.5f\n",cjc);
		sleep(1);
	}
*/
/*
	DWORD rvdword[8];
        BYTE ChStatus[8];
        char status[3][12] = {"CHSTA_GOOD","CHSTA_OVER","CHSTA_UNDER"};

        USBIO_AI_ReadValueHex(DevNum, rvdword);
        USBIO_AI_ReadValueHexWithChSta(DevNum, rvdword, ChStatus);
        for(i = 0; i < 8; i++)
                printf("rvdowrd is %d  channel status is %s\n",rvdword[i],status[ChStatus[i]]);
*/
/*
	float rvdword[8];
        BYTE ChStatus[8];
	char status[3][12] = {"CHSTA_GOOD","CHSTA_OVER","CHSTA_UNDER"};

	USBIO_AI_ReadValueFloat(DevNum, rvdword);
	USBIO_AI_ReadValueFloatWithChSta(DevNum, rvdword, ChStatus);
	for(i = 0; i < 8; i++)
		printf("rvdowrd is %.3f  channel status is %s\n",rvdword[i],status[ChStatus[i]]);
*/
	res = USBIO_CloseDevice(DevNum);

	if(res)
	{
                printf("close /dev/hidraw%d failed! Erro : %d\r\n",  DevNum, res);
                return 0;
        }

	return 0;
}
