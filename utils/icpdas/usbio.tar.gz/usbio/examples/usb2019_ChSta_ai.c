/*
 *  usb2019_ai.c
 *
 *  v 0.0.0 2014.4.14 by Winson Chen
 *
 *    create
 *
 */

#include "ICPDAS_USBIO.h"

int main()
{
	int res,i;
	int DevNum;
	BYTE BoardID = 0x1;
	float AIValue[8];
	BYTE total_ai, type_code[8], ChStatus[8];
	char status[3][12] = {"CHSTA_GOOD","CHSTA_OVER","CHSTA_UNDER"};

	printf("USB I/O Library Version : %s\n", USBIO_GetLibraryVersion());

	res = USBIO_OpenDevice(BoardID, &DevNum);

	if(res)
	{
		printf("open /dev/hidraw%d faild! Erro : %d\r\n", DevNum, res);
		return 0;
	}

	USBIO_GetAITotal(DevNum, &total_ai);
        printf("USB-2019 AI Number : %d\n\n",total_ai);

	USBIO_AI_SetTypeCodeToChannel(DevNum, 0, 0x1a);

        USBIO_AI_GetTypeCode(DevNum, type_code);
	USBIO_AI_ReadValueFloatWithChSta(DevNum, AIValue, ChStatus);

	printf("  Type code  AIValue  Status\n");

        for(i = 0; i < total_ai; i++)
                printf("Ch%d  0x%02x,  % .3f,  %s\n", i, type_code[i], AIValue[i], status[ChStatus[i]]);

	res = USBIO_CloseDevice(DevNum);

	if(res)
        {
                printf("close /dev/hidraw%d faild! Erro : %d\r\n", DevNum, res);
                return 0;
        }

	return 0;
}
