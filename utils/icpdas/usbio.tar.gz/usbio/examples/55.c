/*
 *  usb2055_ai.c
 *
 *  v 0.0.0 2014.4.21 by Winson Chen
 *
 *  create
 *
 */

#include "ICPDAS_USBIO.h"

int main()
{
        int res,i;
        int DevNum;
	BYTE BoardID = 0x33;

        printf("USB I/O Library Version : %s\n", USBIO_GetLibraryVersion());

	res = USBIO_OpenDevice(BoardID, &DevNum);

        if (res)
        {
                printf("open /dev/hidraw%d failed! Erro : %d\r\n",  DevNum, res);
                return 0;
        }
	//USBIO_LoadDefault(DevNum);

/*
	WORD FilterWidth;
	//USBIO_DI_SetDigitalFilterWidth(DevNum, 100);
	USBIO_DI_GetDigitalFilterWidth(DevNum, &FilterWidth);  //default is 100
	printf("DigitalFilterWidth is %d\n",FilterWidth);
*/
/*
	DWORD inverse;
	USBIO_DI_SetDigitalValueInverse(DevNum, 2);
	USBIO_DI_GetDigitalValueInverse(DevNum, &inverse);  //default is 0
	printf("DigitalValueInverse is %d\n",inverse);
*/

	DWORD trig;
        //USBIO_DI_SetCntEdgeTrigger(DevNum, 1);
	USBIO_DI_GetCntEdgeTrigger(DevNum, &trig);  //default is 0
	printf("CntEdgeTrigger is %d\n",trig);

	WORD CounterValue[8];
	USBIO_DI_WriteClearCounter(DevNum, 3);
	USBIO_DI_WriteClearCounterByMask(DevNum, 0xff);
	USBIO_DI_ReadCounterValue(DevNum, CounterValue);
	for(i = 0;i < 8;i++)
		printf("ReadCounterValue is %d\n",CounterValue[i]);


	BYTE value;
	USBIO_DI_ReadValue(DevNum, &value);
	for(i = 0; i < 8; i++)
	{
		if((value >> i) & 1)
			printf("%d\n",i);
	}
	printf("Read value %d\n",value);

        res = USBIO_CloseDevice(DevNum);

        if (res)
        {
                printf("close /dev/hidraw%d failed! Erro : %d\r\n",  DevNum, res);
                return 0;
        }
}
