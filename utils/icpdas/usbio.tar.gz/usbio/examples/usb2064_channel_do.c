/*
 *  dio.c
 *
 *  v 0.0 2013.3.29 by Golden Wang
 *
 *  Opening USB-2064 and enable the DO of channel[1].
 *
 */

#include "ICPDAS_USBIO.h"

int main()
{
	int fd;						/* file descriptor */
	int res;
	BYTE total_do = 0, do_conf = 0, do_channel, do_enable;
	int DevNum;
	BYTE BoardID = 0x1;

	printf("USB I/O Library Version : %s\n", USBIO_GetLibraryVersion());

	res = USBIO_OpenDevice(BoardID, &DevNum);

        if (res)
        {
                printf("open /dev/hidraw%d failed! Erro : %d\r\n",  DevNum, res);
                return 0;
        }

	USBIO_GetDOTotal(DevNum, &total_do);
        printf("USB-2064 DO Number : %d\n",total_do);

	do_channel = 0;
	do_enable = 1;
	USBIO_DO_WriteValueToChannel(DevNum, do_channel, do_enable);
	printf("USB-2064 DO Channel[%d] : Enable\n",do_channel);

	USBIO_DO_ReadValue(DevNum, &do_conf);
	printf("USB-2064 DO Config : 0x%x\n", do_conf);

	sleep(3);

	do_channel = 0;
        do_enable = 0;
        USBIO_DO_WriteValueToChannel(DevNum, do_channel, do_enable);
	printf("USB-2064 DO Channel[%d] : Disable\n",do_channel);

        USBIO_DO_ReadValue(DevNum, &do_conf);
        printf("USB Device DO Config : 0x%x\n",do_conf);

	res = USBIO_CloseDevice(DevNum);

	if(res)
	{
                printf("close /dev/hidraw%d failed! Erro : %d\r\n",  DevNum, res);
                return 0;
        }

	return (0);
}
