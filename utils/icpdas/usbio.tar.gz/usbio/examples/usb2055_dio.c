/*
 *  usb2055_dio.c
 *
 *  v 0.0.1 2014.12.8 by Winson Chen
 *
 *  Add Write DO function and rename usb2055_dio.c
 *
 *  v 0.0.0 2014.4.28 by Winson Chen
 *
 *  create
 *
 */

#include "ICPDAS_USBIO.h"

int main()
{
        int res,i,tmp;
        int DevNum;
	BYTE total_di, total_do, DIValue, DOValue;
	BYTE BoardID = 0x1;

        printf("USB I/O Library Version : %s\n", USBIO_GetLibraryVersion());
	
	res = USBIO_OpenDevice(BoardID, &DevNum);

	USBIO_SetUserDefinedBoardID(DevNum, 0x16);

        if (res)
        {
                printf("open /dev/hidraw%d failed! Erro : %d\r\n", DevNum, res);
                return 0;
        }

	USBIO_GetDOTotal(DevNum, &total_do);
	printf("USB-2055 DO number: %d\n",total_do);

	USBIO_GetDITotal(DevNum, &total_di);
	printf("USB-2055 DI number: %d\n\n",total_di);

	while(1)
	{
		printf("Press ESC to exit.\n\n");

		printf("Enter DO value(0~%.0f):",pow(2,total_do)-1);
		scanf("%d",&tmp);
		if(getchar() == 27)
			break;
		sprintf(&DOValue,"%c",tmp);
		printf("Do Value is %d\n",DOValue);
		USBIO_DO_WriteValue(DevNum, &DOValue);
	        printf("USB-2055 DO Value : 0x%x\n",DOValue);
		
		usleep(40000);
		USBIO_DI_ReadValue(DevNum, &DIValue);

	        for(i = 0; i < total_di; i++)
        	{
	                if((DIValue >> i) & 1)
                        	printf("Ch%d DI  On \n",i);
                	else
        	                printf("Ch%d DI Off \n",i);
	        }
		printf("\n");
	}

	DOValue = 0;        //Disable all USB-2055 DO channel
        USBIO_DO_WriteValue(DevNum, &DOValue);

        res = USBIO_CloseDevice(DevNum);

        if (res)
        {
                printf("close /dev/hidraw%d failed! Erro : %d\r\n",  DevNum, res);
                return 0;
        }

	return 0;
}
