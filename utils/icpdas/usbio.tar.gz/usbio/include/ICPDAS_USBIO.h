/**********************************************************************
 *
 *  ICPDAS_USBIO.h
 *
 *  Header of USB I/O Linux Library
 *
 *  v 0.0.2 2014.4.14 by WInson Chen
 *
 *    To add USBIO DI,AI,PI function name.
 *    To add USB serial device API's function name.
 *
 *  v 0.0.1 2013.4.10 by Golden Wang
 *
 *    To modify the API's function name.
 *
 *  v 0.0.0 2013.4.9 by Golden Wang
 *
 *    create
 *
 **********************************************************************/

/* Linux */
#include "USBIO_Device.h"
#include <linux/types.h>
#include <linux/input.h>
#include <linux/hidraw.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <pthread.h>
#include <unistd.h>
#include <math.h>

typedef unsigned int BOOL;
typedef unsigned char BYTE;
typedef unsigned short WORD;
typedef unsigned long DWORD;

/* USBIO Device-ID */
#define USBIO_MINPID  0x0400
#define USB2019       (USBIO_MINPID+19)
#define USB2055       (USBIO_MINPID+55)
#define USB2064       (USBIO_MINPID+64)
#define USB2084       (USBIO_MINPID+84)

#define DEV_RETURN_ERR_CODE_BASE  0
#define DEVLIB_ERR_CODE_BASE      0x10000
#define IOLIB_ERR_CODE_BASE       0x10100

#define ERR_NO_ERR                0
/* USBDEV Error Codes */
#define ERR_USBDEV_INVALID_DEV           (DEVLIB_ERR_CODE_BASE + 0)
#define ERR_USBDEV_DEV_OPENED            (DEVLIB_ERR_CODE_BASE + 1)
#define ERR_USBDEV_DEVNOTEXISTS          (DEVLIB_ERR_CODE_BASE + 2)
#define ERR_USBDEV_GETDEVINFO            (DEVLIB_ERR_CODE_BASE + 3)
#define ERR_USBDEV_ERROR_PKTSIZE         (DEVLIB_ERR_CODE_BASE + 4)
#define ERR_USBDEV_ERROR_WRITEFILE       (DEVLIB_ERR_CODE_BASE + 5)
#define ERR_USBDEV_ERROR_OPENFILE        (DEVLIB_ERR_CODE_BASE + 6)  
#define ERR_USBDEV_ERROR_CreateRxThread  (DEVLIB_ERR_CODE_BASE + 7)
#define ERR_USBDEV_ERROR_RestartRxThread (DEVLIB_ERR_CODE_BASE + 8)

/* USBIO Error Codes */
#define ERR_USBIO_COMM_TIMEOUT      (IOLIB_ERR_CODE_BASE + 0)
#define ERR_USBIO_DEV_OPENED        (IOLIB_ERR_CODE_BASE + 1)
#define ERR_USBIO_DEV_NOTOPEN       (IOLIB_ERR_CODE_BASE + 2)
#define ERR_USBIO_INVALID_RESP      (IOLIB_ERR_CODE_BASE + 3)
#define ERR_USBIO_IO_NOTSUPPORT     (IOLIB_ERR_CODE_BASE + 4)
#define ERR_USBIO_PARA_ERROR        (IOLIB_ERR_CODE_BASE + 5)
#define ERR_USBIO_BULKVALUE_ERR     (IOLIB_ERR_CODE_BASE + 6)
#define ERR_USBIO_GETDEVINFO        (IOLIB_ERR_CODE_BASE + 7)

/* Channel Status */
#define CHSTA_GOOD            0
#define CHSTA_OVER            1
#define CHSTA_UNDER           2
#define CHSTA_OPEN            3
#define CHSTA_CLOSE           4
#define CHSTA_TYPENOTSUPPORT  5

typedef void (*OnBulkValueFinishEvent) (DWORD dwCount);
typedef void (*OnEmergencyPktArriveEvent) (BYTE * byData, BYTE byLen);

/* Get the information of USB I/O modules */
char *USBIO_GetLibraryVersion(void);  //test ok
int USBIO_Test(BYTE HIDDev);
int USBIO_OpenDevice(BYTE BOARDID, int *DevNum);  //test ok
int USBIO_CloseDevice(BYTE HIDDev);  //test ok
int USBIO_RefreshDeviceInfo(BYTE HIDDev);  //test ok
//int SYNCDevice(void);
int USBIO_SetCommTimeout(BYTE HIDDev, DWORD i_dwCommTimeout);  //test ok
int USBIO_GetCommTimeout(BYTE HIDDev, DWORD * o_dwCommTimeout);  //test ok
int USBIO_SetAutoResetWDT(BYTE HIDDev, BOOL i_bEnable);
int USBIO_GetSoftWDTTimeout(BYTE HIDDev, DWORD * o_dwSoftWDTTimeout);  //test ok
int USBIO_GetSupportIOMask(BYTE HIDDev, BYTE * o_bySupportIOMask);
int USBIO_GetDeviceID(BYTE HIDDev, DWORD * o_dwDeviceID);  //test ok
int USBIO_GetFwVer(BYTE HIDDev, WORD * o_wFwVer);  //test ok
int USBIO_GetDeviceNickName(BYTE HIDDev, BYTE * o_byDeviceNickName);  //test ok
int USBIO_GetDeviceSN(BYTE HIDDev, BYTE * o_byDeviceSN);
int USBIO_GetDITotal(BYTE HIDDev, BYTE * o_byDITotal);  //test ok
int USBIO_GetDOTotal(BYTE HIDDev, BYTE * o_byDOTotal);  //test ok
int USBIO_GetAITotal(BYTE HIDDev, BYTE * o_byAITotal);  //test ok
int USBIO_GetAOTotal(BYTE HIDDev, BYTE * o_byAOTotal);
int USBIO_GetPITotal(BYTE HIDDev, BYTE * o_byPITotal);  //test ok
int USBIO_GetPOTotal(BYTE HIDDev, BYTE * o_byPOTotal);
int USBIO_SendRecv(BYTE HIDDev, BYTE * i_bySend, WORD wData_Len, BYTE * o_byRecv);  //test ok

// DEVICE (Set)  //addmyself below  golden did't add these on first time
int USBIO_SetUserDefinedBoardID(BYTE HIDDev, BYTE i_byBID);  //test ok
int USBIO_SetDeviceNickName(BYTE HIDDev, BYTE* i_byDeviceNickName);  //test ok
int USBIO_SetSoftWDTTimeout(BYTE HIDDev, DWORD i_dwSoftWDTTimeout);  //test ok
int USBIO_LoadDefault(BYTE HIDDev);  //test ok
int USBIO_StopBulk(BYTE HIDDev);

// CALLBACK REGISTRATION  //addmyself
int USBIO_RegisterEmergencyPktEventHandle(BYTE HIDDev, OnEmergencyPktArriveEvent i_evtHandle);

/* Get DO configuration and data */
int USBIO_DO_GetPowerOnEnable(BYTE HIDDev, BYTE * o_byPowerOnEnable);  //addmyself below
int USBIO_DO_GetSafetyEnable(BYTE HIDDev, BYTE * o_bySafetyEnable);
int USBIO_DO_GetSafetyValue(BYTE HIDDev, BYTE * o_bySafetyValue);
int USBIO_DO_ReadValue(BYTE HIDDev, BYTE * o_byDOValue);

/* Set DO configuration and data */
int USBIO_DO_SetPowerOnEnableToChannel(BYTE HIDDev, BYTE i_byChToSet, BYTE i_byPowerOnEnable);
int USBIO_DO_SetPowerOnEnable(BYTE HIDDev, BYTE* i_byPowerOnEnables);
int USBIO_DO_SetSafetyEnable(BYTE HIDDev, BYTE* i_bySafetyEnable);
int USBIO_DO_SetSafetyValue(BYTE HIDDev, BYTE* i_bySafetyValue);
int USBIO_DO_WriteValue(BYTE HIDDev, BYTE* i_byDOValue);
int USBIO_DO_WriteValueToChannel(BYTE HIDDev, BYTE i_byChannel, BYTE i_byValue);  //addmyself above

/* Get DI configuration and data */
int USBIO_DI_GetDigitalFilterWidth(BYTE HIDDev, WORD* o_wFilterWidth);  //test ok
int USBIO_DI_GetDigitalValueInverse(BYTE HIDDev, DWORD* o_dwInverse);  //test ok
int USBIO_DI_GetCntEdgeTrigger(BYTE HIDDev, DWORD* o_dwEdgeTrig);  //test ok
int USBIO_DI_ReadValue(BYTE HIDDev, BYTE* o_byDIValue);  //test ok
int USBIO_DI_ReadCounterValue(BYTE HIDDev, WORD* o_wDICntValue);  //test ok

/* Set DI configuration and data */
int USBIO_DI_SetDigitalFilterWidth(BYTE HIDDev, WORD i_wFilterWidth);  //test ok
int USBIO_DI_SetDigitalValueInverse(BYTE HIDDev, DWORD i_dwInverse);  //test ok
int USBIO_DI_SetCntEdgeTrigger(BYTE HIDDev, DWORD i_dwEdgeTrig);  //test ok
int USBIO_DI_WriteClearCounter(BYTE HIDDev, BYTE i_byChToClr);  //test ok
int USBIO_DI_WriteClearCounterByMask(BYTE HIDDev, DWORD i_dwCntClrMask);  //test ok

/* Get AI configuration and data */
int USBIO_AI_GetTotalSupportType(BYTE HIDDev, BYTE * o_byTotalSupportType);  //test ok
int USBIO_AI_GetSupportTypeCode(BYTE HIDDev, BYTE* o_bySupportTypeCode);  //test ok
int USBIO_AI_GetTypeCode(BYTE HIDDev, BYTE* o_byTypeCode);  //test ok
int USBIO_AI_GetChCJCOffset(BYTE HIDDev, float* o_fChCJCOffset);  //test ok
int USBIO_AI_GetChEnable(BYTE HIDDev, BYTE* o_byChEnable);  //test ok
int USBIO_AI_GetDataFormat(BYTE HIDDev, BYTE* o_byDataFormat);  //test ok Hide
int USBIO_AI_GetFilterRejection(BYTE HIDDev, BYTE* o_byFilterRejection);  //test ok
int USBIO_AI_GetCJCOffset(BYTE HIDDev, float* o_fCJCOffset);  //test ok
int USBIO_AI_GetCJCEnable(BYTE HIDDev, BYTE* o_byCJCEnable);  //test ok
int USBIO_AI_GetWireDetectEnable(BYTE HIDDev, BYTE* o_byWireDetectEnable);  //test ok
int USBIO_AI_GetResolution(BYTE HIDDev, BYTE* o_byResolution);  //test ok
int USBIO_AI_ReadValueHex(BYTE HIDDev, DWORD* o_dwAIValue);  //test ok
int USBIO_AI_ReadValueHexWithChSta(BYTE HIDDev, DWORD* o_dwAIValue, BYTE* o_byChStatus);  //test ok
int USBIO_AI_ReadValueFloat(BYTE HIDDev, float* o_fAIValue);  //test ok
int USBIO_AI_ReadValueFloatWithChSta(BYTE HIDDev, float* o_fAIValue, BYTE* o_byChStatus);  //test ok
int USBIO_AI_ReadBulkValue(BYTE HIDDev, 
			   BYTE i_byStartCh,
			   BYTE i_byChTotal,
			   DWORD i_dwSampleWidth,
			   float i_fSampleRate,
			   DWORD i_dwBufferWidth,
			   DWORD* o_dwDataBuffer,
			   OnBulkValueFinishEvent i_CBFunc);

int USBIO_AI_ReadCJCValue(BYTE HIDDev, float* o_fCJCValue);  //test ok

/* Set AI configuration */
int USBIO_AI_SetTypeCodeToChannel(BYTE HIDDev, BYTE i_byChToSet, BYTE i_byTypeCode);  //test ok
int USBIO_AI_SetTypeCode(BYTE HIDDev, BYTE* i_byTypeCodes);  //test ok
int USBIO_AI_SetChCJCOffsetToChannel(BYTE HIDDev, BYTE i_byChToSet, float i_fChCJCOffset);  //test ok
int USBIO_AI_SetChCJCOffset(BYTE HIDDev, float* i_fChCJCOffsets);  //test ok
int USBIO_AI_SetChEnable(BYTE HIDDev, BYTE* i_byChEnable);  //test ok
int USBIO_AI_SetDataFormat(BYTE HIDDev, BYTE i_byDataFormat);  //test ok  Hide
int USBIO_AI_SetFilterRejection(BYTE HIDDev, BYTE i_byFilterRejection);  //test ok
int USBIO_AI_SetCJCOffset(BYTE HIDDev, float i_fCJCOffset);  //test ok
int USBIO_AI_SetCJCEnable(BYTE HIDDev, BYTE i_byCJCEnable);  //test ok
int USBIO_AI_SetWireDetectEnable(BYTE HIDDev, BYTE i_byWireDetectEnable);  //test ok

/* Get PI configuration and data */
int USBIO_PI_GetTotalSupportType(BYTE HIDDev, BYTE* o_byTotalSupportType);  //test ok
int USBIO_PI_GetSupportTypeCode(BYTE HIDDev, BYTE* o_bySupportTypeCode);  //test ok
int USBIO_PI_GetTypeCode(BYTE HIDDev, BYTE* o_byTypeCode);  //test ok
int USBIO_PI_GetTriggerMode(BYTE HIDDev, BYTE* o_byTriggerMode);  //test ok
int USBIO_PI_GetChIsolatedFlag(BYTE HIDDev, BYTE* o_byChIsolatedFlag);  //test ok
int USBIO_PI_GetLPFilterEnable(BYTE HIDDev, BYTE* o_byLPFilterEnable);  //test ok
int USBIO_PI_GetLPFilterWidth(BYTE HIDDev, WORD* o_wLPFilterWidth);  //test ok
int USBIO_PI_ReadValue(BYTE HIDDev, DWORD* o_dwPIValue, BYTE* o_byChStatus);  //test ok
int USBIO_PI_ReadCntValue(BYTE HIDDev, DWORD* o_dwCntValue, BYTE* o_byChStatus);
int USBIO_PI_ReadFreqValue(BYTE HIDDev, float* o_fFreqValue, BYTE* o_byChStatus);
int USBIO_PI_ReadBulkValue(BYTE HIDDev,
                               BYTE i_byStartCh,
                               BYTE i_byChTotal,
                               DWORD i_dwSampleWidth,
                               float i_fSampleRate,
                               DWORD i_dwBufferWidth,
                               DWORD* o_dwDataBuffer,
                               OnBulkValueFinishEvent i_CBFunc);

/* Set PI configuration and data */
int USBIO_PI_SetTypeCodeToChannel(BYTE HIDDev, BYTE i_byChToSet, BYTE i_byTypeCode);  //test ok
int USBIO_PI_SetTypeCode(BYTE HIDDev, BYTE* i_byTypeCodes);  //test ok
int USBIO_PI_ClearSingleChCount(BYTE HIDDev, BYTE i_byChToClr);  //test ok
int USBIO_PI_ClearChCount(BYTE HIDDev, BYTE* i_byClrMask);  //test ok
int USBIO_PI_ClearSingleChStatus(BYTE HIDDev, BYTE i_byChToClr);
int USBIO_PI_ClearChStatus(BYTE HIDDev, BYTE* i_byClrMask);
//int USBIO_PI_ClearAllChCount(BYTE HIDDev);
int USBIO_PI_SetTriggerModeToChannel(BYTE HIDDev, BYTE i_byChToSet, BYTE i_byTriggerMode);  //test ok
int USBIO_PI_SetTriggerMode(BYTE HIDDev, BYTE* i_byTriggerModes);  //test ok
int USBIO_PI_SetChIsolatedFlagToChannel(BYTE HIDDev, BYTE i_byChToSet, BOOL i_bChIsolatedFlag);  //test ok
int USBIO_PI_SetChIsolatedFlag(BYTE HIDDev, BYTE* i_byChIsolatedFlag);  //test ok
int USBIO_PI_SetLPFilterEnableToChannel(BYTE HIDDev, BYTE i_byChToSet, BOOL i_bLPFilterEnable);  //test ok
int USBIO_PI_SetLPFilterEnable(BYTE HIDDev, BYTE* i_byLPFilterEnables);  //test ok
int USBIO_PI_SetLPFilterWidthToChannel(BYTE HIDDev, BYTE i_byChToSet, WORD i_wLPFilterWidth);  //test ok
int USBIO_PI_SetLPFilterWidth(BYTE HIDDev, WORD* i_wLPFilterWidths);  //test ok
