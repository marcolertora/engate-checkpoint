/**********************************************************************
 *
 *  USBIO_Device.h
 *
 *  Header of USB I/O Device
 *
 *  v 0.0.0 2013.4.9 by Golden Wang
 *
 *    create
 *
 **********************************************************************/



#define MAX_USB_DEVICES 127
#define HIDRAW0       0
#define HIDRAW1       1
#define HIDRAW2       2
#define HIDRAW3       3
#define HIDRAW4       4
#define HIDRAW5       5
#define HIDRAW6       6
#define HIDRAW7       7
#define HIDRAW8       8
#define HIDRAW9       9

#define HIDRAW10      10
#define HIDRAW11      11
#define HIDRAW12      12
#define HIDRAW13      13
#define HIDRAW14      14
#define HIDRAW15      15
#define HIDRAW16      16
#define HIDRAW17      17
#define HIDRAW18      18
#define HIDRAW19      19

#define HIDRAW20      20
#define HIDRAW21      21
#define HIDRAW22      22
#define HIDRAW23      23
#define HIDRAW24      24
#define HIDRAW25      25
#define HIDRAW26      26
#define HIDRAW27      27
#define HIDRAW28      28
#define HIDRAW29      29

#define HIDRAW30      30
#define HIDRAW31      31
#define HIDRAW32      32
#define HIDRAW33      33
#define HIDRAW34      34
#define HIDRAW35      35
#define HIDRAW36      36
#define HIDRAW37      37
#define HIDRAW38      38
#define HIDRAW39      39

#define HIDRAW40      40
#define HIDRAW41      41
#define HIDRAW42      42
#define HIDRAW43      43
#define HIDRAW44      44
#define HIDRAW45      45
#define HIDRAW46      46
#define HIDRAW47      47
#define HIDRAW48      48
#define HIDRAW49      49

#define HIDRAW50      50
#define HIDRAW51      51
#define HIDRAW52      52
#define HIDRAW53      53
#define HIDRAW54      54
#define HIDRAW55      55
#define HIDRAW56      56
#define HIDRAW57      57
#define HIDRAW58      58
#define HIDRAW59      59

#define HIDRAW60      60
#define HIDRAW61      61
#define HIDRAW62      62
#define HIDRAW63      63
#define HIDRAW64      64
#define HIDRAW65      65
#define HIDRAW66      66
#define HIDRAW67      67
#define HIDRAW68      68
#define HIDRAW69      69

#define HIDRAW70      70
#define HIDRAW71      71
#define HIDRAW72      72
#define HIDRAW73      73
#define HIDRAW74      74
#define HIDRAW75      75
#define HIDRAW76      76
#define HIDRAW77      77
#define HIDRAW78      78
#define HIDRAW79      79

#define HIDRAW80      80
#define HIDRAW81      81
#define HIDRAW82      82
#define HIDRAW83      83
#define HIDRAW84      84
#define HIDRAW85      85
#define HIDRAW86      86
#define HIDRAW87      87
#define HIDRAW88      88
#define HIDRAW89      89

#define HIDRAW90      90
#define HIDRAW91      91
#define HIDRAW92      92
#define HIDRAW93      93
#define HIDRAW94      94
#define HIDRAW95      95
#define HIDRAW96      96
#define HIDRAW97      97
#define HIDRAW98      98
#define HIDRAW99      99

#define HIDRAW100     100
#define HIDRAW101     101
#define HIDRAW102     102
#define HIDRAW103     103
#define HIDRAW104     104
#define HIDRAW105     105
#define HIDRAW106     106
#define HIDRAW107     107
#define HIDRAW108     108
#define HIDRAW109     109

#define HIDRAW110     110
#define HIDRAW111     111
#define HIDRAW112     112
#define HIDRAW113     113
#define HIDRAW114     114
#define HIDRAW115     115
#define HIDRAW116     116
#define HIDRAW117     117
#define HIDRAW118     118
#define HIDRAW119     119

#define HIDRAW120     120
#define HIDRAW121     121
#define HIDRAW122     122
#define HIDRAW123     123
#define HIDRAW124     124
#define HIDRAW125     125
#define HIDRAW126     127
